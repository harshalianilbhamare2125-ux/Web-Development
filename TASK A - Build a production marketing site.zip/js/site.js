/**
 * Portside — site.js
 * Progressive enhancement only. Nothing on this site depends on JS to
 * render content or be readable/crawlable — this file just improves the
 * mobile nav interaction and keeps aria-expanded in sync. Loaded with
 * `defer` on every page so it never blocks first paint.
 */
(function () {
  "use strict";

  var toggle = document.querySelector(".nav-toggle");
  var nav = document.getElementById("primary-nav-panel");

  if (toggle && nav) {
    toggle.addEventListener("click", function () {
      var isOpen = nav.classList.toggle("open");
      toggle.setAttribute("aria-expanded", String(isOpen));
    });

    // Close the mobile nav on Escape, return focus to the toggle button
    nav.addEventListener("keydown", function (e) {
      if (e.key === "Escape") {
        nav.classList.remove("open");
        toggle.setAttribute("aria-expanded", "false");
        toggle.focus();
      }
    });
  }
})();
