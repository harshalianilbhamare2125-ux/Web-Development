# Core Web Vitals — strategy & evidence

**Important caveat first:** I built and validated this site in a sandboxed environment with no network access and no hosting — I cannot run a live Lighthouse or PageSpeed Insights audit against a real URL from here, and I won't fabricate a score screenshot. Everything below is (a) the concrete design decisions made to hit green CWV, and (b) exact steps to generate your own evidence in ~2 minutes once you deploy. Nothing in this build works against these numbers; the architecture was chosen specifically to make them easy to hit.

## Strategy, metric by metric

### LCP (Largest Contentful Paint)
- **Zero raster images in the critical path.** Every hero graphic and icon on every page is inline SVG — no image request, no decode time, nothing for the browser to wait on for the largest element. The only raster image on the whole site (`assets/og-image.png`) is never rendered on-page; it's a social-share asset only.
- **No hero video, no carousel, no above-the-fold JS-rendered content.** The LCP element on every page is text (`<h1>`) or an inline SVG, both paint on first pass with the HTML/CSS.
- **Fonts don't block paint.** Google Fonts are loaded with `rel="preconnect"` plus `display=swap` in the font URL, so text renders immediately in a fallback font and swaps once the webfont loads — never a blank-text wait.
- **One CSS file, no @import chains, no CSS-in-JS runtime.** `style.css` is the only stylesheet and loads in parallel with the HTML parse.

### CLS (Cumulative Layout Shift)
- **SVGs use `viewBox` with no fixed pixel dimensions**, so they reserve their aspect ratio immediately without a resize jump once "loaded" (they're inline — there's no load event to jump on).
- **No web fonts causing reflow surprises**: `font-display: swap` does cause a swap, but Space Grotesk/Source Sans/JetBrains Mono are all reasonably metric-compatible with their system fallbacks at the sizes used here; nothing is set in a fixed-height container that would clip or reflow on swap.
- **No lazy-loaded ads, embeds, or cookie banners** — the top three real-world CLS offenders — exist on this site at all.
- **Mobile nav** overlays rather than push-shifting page content, so opening it never moves anything else on the page.

### INP (Interaction to Next Paint)
- **`js/site.js` is 20 lines** and does exactly one thing (mobile nav toggle) — there's no framework hydration, no event-delegation overhead, nothing competing with user input on the main thread.
- Script is loaded with `defer` on every page, so it never blocks parsing or first paint, and it finishes executing well before a user can realistically interact.
- The FAQ accordion uses native `<details>/<summary>` instead of a JS-driven accordion — the browser handles the toggle natively with no script involved and no INP cost.

### General
- No third-party analytics, chat widgets, or ad scripts are included in this build. Each of those is a common source of both LCP and INP regressions in real marketing sites — if you add one post-launch (e.g. a support chat widget), load it deferred/on-interaction rather than in `<head>`, and re-test.

## How to generate your own evidence (once deployed)

1. Deploy using any option in `README.md` → Deploy (GitHub Pages, Netlify, or Vercel all work with zero config since there's no build step).
2. Go to **[PageSpeed Insights](https://pagespeed.web.dev/)**, enter your live URL, run it once per page (Home, Product, Pricing, Contact) on the **Mobile** tab.
3. Screenshot the "Core Web Vitals Assessment: Passed" banner and the field/lab data section for each page.
4. Alternatively, in Chrome DevTools → Lighthouse tab → check "Performance" + "Mobile" → Analyze page load. Export as HTML or JSON for a more detailed artifact than a screenshot.
5. Attach both PageSpeed and Lighthouse output for all 4 pages as your submission evidence, per the task's deliverable list.

Given the architecture above (no render-blocking scripts, no layout-shifting late-loading elements, no heavy LCP candidate), you should see green across all three Core Web Vitals on every page without further tuning. If any page comes back non-green, the most likely cause in a build like this is network conditions in the test environment or a font-loading edge case — not the page structure itself; re-test before changing anything structural.
