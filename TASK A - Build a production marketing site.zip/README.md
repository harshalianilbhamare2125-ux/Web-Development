# Portside — Marketing Site

A 4-page B2B marketing site for **Portside** (fictional freight-visibility SaaS for mid-market shippers), built with hand-written semantic HTML, one shared CSS file, and one small progressive-enhancement JS file. No page builder, no framework, no build step — open any `.html` file in a browser and it works.

## Live URL

> Replace with your deployed URL after publishing (see **Deploy**, below):
> `https://YOUR-DEPLOYMENT-URL`

## Structure

```
/
├── index.html         Home
├── product.html        Product
├── pricing.html         Pricing (+ FAQ)
├── contact.html         Contact
├── css/style.css         Shared stylesheet — tokens + components
├── js/site.js          Progressive enhancement only (mobile nav)
├── assets/
│   ├── favicon.svg       Brand mark, used as favicon
│   └── og-image.png     1200×630 social share image
├── robots.txt
└── sitemap.xml
```

## Architecture — why a content team can extend this without touching layout

**One CSS file, organized top to bottom as: tokens → base → layout primitives → components.**
Every visual decision (color, spacing, radius, font) is a CSS custom property in `:root`. A content editor never needs to open `style.css` at all — every page is built from the same set of pre-styled, reusable classes:

- `.hero`, `.section`, `.section-tight` — page rhythm
- `.card`, `.plan`, `.faq details` — repeatable content blocks
- `.grid-2` / `.grid-3` — layout without custom CSS per page
- `.btn-primary` / `.btn-secondary` — the only two button styles in the system

**Adding content = duplicating a block, not writing new markup.**
For example, to add a 4th pricing plan, copy one `<div class="plan">…</div>` block in `pricing.html` and edit the text inside it — the grid, spacing, and card styling all come from the existing CSS automatically. Same pattern for FAQ items (`<details><summary>…</summary><p>…</p></details>`), feature cards, and comparison-table rows. Nobody has to touch `style.css` to add a plan, a FAQ, or a feature card.

**Header and footer are identical on every page by design**, so global nav/footer changes are a find-and-replace across 4 files rather than a templating system — deliberate, given the "no page builder" constraint. If this site grows past ~8–10 pages, the natural next step is a static site generator (11ty/Astro) purely to de-duplicate that header/footer block; the component boundaries in this CSS are already shaped for that migration (nothing here assumes inline duplication is permanent).

**`site.js` never renders content.** It only handles the mobile nav toggle. This is a deliberate performance and SEO choice, not an oversight — see `PERFORMANCE.md`.

## Accessibility

- Skip link on every page, jumps to `#main`
- Full semantic landmarks: `header`, `nav[aria-label]`, `main`, `footer`
- One `<h1>` per page, strictly nested `h2`/`h3` below it (verified programmatically, see below)
- Visible focus ring on every interactive element (`:focus-visible`, never suppressed)
- Mobile nav: real `<button>` with `aria-expanded`/`aria-controls`, closes on <kbd>Escape</kbd> and returns focus to the toggle
- FAQ uses native `<details>/<summary>` — keyboard and screen-reader accessible with zero JS
- Form: every input has a bound `<label>`, grouped radio inputs use `<fieldset>/<legend>`, hints are wired via `aria-describedby`, required fields marked both visually and with `aria-required`
- `prefers-reduced-motion` respected globally

## Structured data & meta

Every page has: unique `<title>`, meta description, canonical URL, full Open Graph + Twitter Card tags, and a shared `assets/og-image.png` (1200×630, generated — swap for a real brand asset before shipping).

JSON-LD:
- **Organization** — every page
- **SoftwareApplication** (with `offers`) — `product.html`
- **FAQPage** — `pricing.html`, matching the visible `<details>` FAQ content exactly (no hidden/mismatched schema text)

All JSON-LD blocks were validated as parseable JSON before delivery; run them through [Google's Rich Results Test](https://search.google.com/test/rich-results) after deploying to confirm live rendering.

## Before you deploy

1. Find-and-replace `https://www.portside.io` with your real domain across all 4 HTML files (canonical URLs, OG/Twitter URLs, sitemap.xml, robots.txt).
2. Swap `assets/og-image.png` for a real brand asset if you have one.
3. Point the contact form's `action` at a real static-form backend (Formspree, Netlify Forms, Basin) — the markup doesn't need to change, just the endpoint.
4. Update the footer credit link if `digitalheroesco.com` isn't the correct destination for your submission.

## Deploy (static hosting, no build step)

**GitHub Pages** — push this folder to a repo, then in Settings → Pages, set the source to the `main` branch root. Live in a few minutes at `https://<username>.github.io/<repo>/`.

**Netlify** — drag the folder onto [app.netlify.com/drop](https://app.netlify.com/drop), or connect the GitHub repo for auto-deploys on push. Also gives you working form handling for `contact.html` for free (`data-netlify="true"` on the `<form>`).

**Vercel** — `vercel` from inside this folder with the CLI, or import the GitHub repo in the dashboard.

## Performance evidence

See `PERFORMANCE.md` for the Core Web Vitals strategy and instructions for capturing your own Lighthouse/PageSpeed report once deployed.
