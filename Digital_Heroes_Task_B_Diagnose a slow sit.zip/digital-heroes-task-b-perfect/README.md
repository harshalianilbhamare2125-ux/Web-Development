# Digital Heroes Task B — Fixed Connected Website

## What was fixed
The previous demo had a simple one-page structure. This version has all sections connected with working anchor navigation:

- Problem → Diagnosis
- Before → Recommendation
- After → Metrics
- Metrics → Back to top
- Buttons and links scroll to the correct section
- The demo interaction works
- Responsive mobile layout included
- Required Digital Heroes footer credit included

## Run locally
Open `demo/index.html` in a browser.

For best results in VS Code, use Live Server.

## Before submitting
1. Run real performance tests.
2. Replace demo placeholder metrics with measured values.
3. Add screenshots/evidence to your report.
4. Publish the `demo` folder.
5. Add your live URL to the report.
6. Share the Google Drive folder and live URL as required by the task.
