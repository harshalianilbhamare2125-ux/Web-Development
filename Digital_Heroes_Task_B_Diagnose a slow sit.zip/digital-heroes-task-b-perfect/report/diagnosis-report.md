# Digital Heroes Task B — Final Diagnosis Report

## Target
Chosen publicly accessible website: **CNN homepage — https://www.cnn.com/**

> Replace the bracketed values with your own current measurements before submitting.

## 1. Evidence

### Field data
Record current CrUX/PageSpeed Insights values:

| Metric | Value |
|---|---:|
| LCP | [your value] |
| INP | [your value] |
| CLS | [your value] |

### Lab data
Run the same mobile test 3 times and report the median:

| Metric | Run 1 | Run 2 | Run 3 | Median |
|---|---:|---:|---:|---:|
| Performance score | | | | |
| LCP | | | | |
| TBT | | | | |
| CLS | | | | |
| Total transfer size | | | | |
| Requests | | | | |

### Specific bottlenecks
1. **Critical above-the-fold media:** verify the LCP element and its request chain. If the LCP asset is large or discovered late, it delays the first useful view.
2. **Main-thread JavaScript:** verify long tasks in the Performance panel and script execution in Lighthouse. Defer non-critical work.
3. **Excessive media bytes:** verify image sizes and responsive delivery in the Network panel.
4. **Below-fold loading:** verify whether off-screen content is being downloaded before it is needed.
5. **Layout shifts:** verify whether media/embed dimensions are reserved.

## 2. Prioritised fix list

| Priority | Fix | Impact | Cost | Decision |
|---|---|---|---|---|
| P0 | Optimise the real LCP element | Very high | Medium | Do first |
| P0 | Defer non-critical third-party scripts | High | Medium | Do first |
| P1 | Responsive images + lazy loading below fold | High | Low–Medium | Strong quick win |
| P1 | Reserve dimensions for media | Medium | Low | Do |
| P2 | Remove unused JavaScript | Medium | Medium–High | Do selectively |
| P3 | Tiny CSS micro-optimisations | Low | Medium | Defer |
| P3 | Chasing a perfect Lighthouse score | Low | High | Do not bother |

## 3. Rebuilt section

The demo rebuilds a representative content section.

### Before
- Heavy visual media is part of the first loading path.
- Secondary cards compete for bandwidth.
- More content is prepared before the user needs it.

### After
- The main message is prioritised.
- The visual treatment is lightweight.
- Secondary content can be deferred.

**Live demo URL:** [insert your published URL]

## 4. Before / after metrics

Use identical mobile conditions and at least 3 runs:

| Metric | Before | After | Change |
|---|---:|---:|---:|
| LCP | | | |
| Total transfer | | | |
| Requests | | | |
| TBT/INP | | | |

## 5. Client-facing summary

The page can feel slow on mobile because too much work happens before the first useful content appears. I recommend focusing first on the content users see immediately: make the main visual asset lighter and easier to discover, delay non-essential scripts, and avoid loading content that is still below the fold.

I would not spend the first sprint chasing tiny CSS improvements or a perfect laboratory score. The highest-value work is the work that makes the page useful sooner and keeps it responsive when users interact with it.

The rebuilt demo proves this recommendation on a focused section. The final before/after metrics should be measured under identical conditions so the improvement is credible.

## 6. Method

- PageSpeed Insights / CrUX for field data when available.
- Lighthouse mobile lab tests, 3 runs, median reported.
- Chrome DevTools Network for request/transfer evidence.
- Chrome DevTools Performance for main-thread and long-task evidence.
